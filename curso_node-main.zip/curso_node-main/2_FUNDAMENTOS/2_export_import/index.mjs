import soma from "./meu_modulo.mjs";

soma(2, 3);
