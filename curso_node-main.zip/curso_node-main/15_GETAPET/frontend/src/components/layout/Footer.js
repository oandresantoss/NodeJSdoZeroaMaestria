import styles from "./Footer.module.css";

function Footer() {
  return <footer className={styles.footer}>
    <p><b>Get A Pet</b> &copy; 2021</p>
  </footer>
}

export default Footer
